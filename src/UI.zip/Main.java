import UI.MainMenu;
import model.InputData;
import service.*;

public class Main {
    public static void main(String... args) {

        System.out.println("\nWitaj w kalkulatorze kredytów hipotecznych! ");

        do
         {
            MainMenu mainMenu = new MainMenu();
            mainMenu.displayMenu();
            InputData inputData = mainMenu.getInputData();
            if(inputData != null) {
                calculateCredit(inputData);
            }
        }
        while(true);
    }

    private static void calculateCredit(InputData inputData) {
        PrintingService printingService = new PrintingServiceImpl();
        RateCalculationService rateCalculationService = new RateCalculationServiceImpl(
                        new TimePointServiceImpl(),
                        new AmountsCalculationServiceImpl(
                                new ConstantAmountsCalculatoinServiceImpl(),
                                new DecreasingAmountsCalculatoinServiceImpl()
                        ),
                        new OverpaymentCalculationServiceImpl(),
                        new ResidiualCalculationServiceImpl(),
                        new ReferenceCalculationServiceImpl()
                );
        MortgageCalculatorService mortgageCalculatorService = new MortgageCalculatorServiceImpl(
                printingService,
                rateCalculationService,
                SummaryServiceFactory.create());
        mortgageCalculatorService.calculate(inputData);
    }
}